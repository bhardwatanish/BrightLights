package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.myapplication.R.layout.activity_main;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_main);
        Button menu=(Button)findViewById(R.id.menu);
        menu.setOnClickListener(new View.OnClickListener() {
        super.onCreate(savedInstanceState);
        setContentView(activity_main);
            @Override
            public void onClick(View v) {
                Intent startintent= new Intent(getApplicationContext(),menuact.class);
                startActivity(startintent);
            }
    }
}
}